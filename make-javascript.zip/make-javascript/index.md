### 完整解析javaScript

### 用例入口
index.js

### parse解析
解析语法分析 parse
### 用例正则匹配
reg.js
### 产生式
production.js 用于指示状态机解析状态