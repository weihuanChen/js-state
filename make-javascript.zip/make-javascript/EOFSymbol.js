class EOFSymbol {
  constructor() {
    this.type = "EOF";
  }
}
module.exports = {
  EOFSymbol
}